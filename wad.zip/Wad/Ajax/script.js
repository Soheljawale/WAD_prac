document.getElementById("regForm").addEventListener("submit", function(e) {
    e.preventDefault();

    // Get values
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let mobile = document.getElementById("mobile").value;

    let userData = {
        name: name,
        email: email,
        mobile: mobile
    };

    // Get existing data from localStorage
    let users = JSON.parse(localStorage.getItem("users")) || [];

    // Push new data
    users.push(userData);

    // Save back to localStorage
    localStorage.setItem("users", JSON.stringify(users));

    // AJAX POST (Dummy API for demonstration)
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "https://jsonplaceholder.typicode.com/posts", true);
    xhr.setRequestHeader("Content-Type", "application/json");

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 201) {
            alert("Data submitted successfully!");
        }
    };

    xhr.send(JSON.stringify(userData));

    // Reset form
    document.getElementById("regForm").reset();
});