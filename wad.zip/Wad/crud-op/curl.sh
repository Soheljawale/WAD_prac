##Start server
npm install
node server.js

## CREATE User (POST)
curl -X POST http://localhost:3000/api/users \
-H "Content-Type: application/json" \
-d '{"name":"Kalash","email":"kalash@gmail.com","age":21}'

## READ All Users (GET)
curl http://localhost:3000/api/users

## READ User by ID (GET)
curl http://localhost:3000/api/users/<USER_ID>

## UPDATE User (PUT)
curl -X PUT http://localhost:3000/api/users/<USER_ID> \
-H "Content-Type: application/json" \
-d '{"name":"Kalash Updated","email":"kalash.updated@gmail.com","age":22}'

## DELETE User (DELETE)
curl -X DELETE http://localhost:3000/api/users/<USER_ID>